# Design Decisions and Open Questions

This is a living decision log for the Sierra Outfitters assessment. It separates what the current MVP does from assumptions and follow-up work so the onsite discussion can focus on intentional tradeoffs.

## Customer problem and scope

**Problem framing.** Sierra expects a seasonal rise in inbound support volume, including product issues. This prototype addresses the explicitly scoped, repeatable requests: order status/tracking, catalog-based product questions, and a time-limited promotion. The goal is quick self-service with trustworthy answers. Product troubleshooting, returns, exchanges, and human escalation are not specified, so the MVP does not invent those policies.

**Experience goal.** Ask for missing information, answer from source records, and say what cannot be verified. Brief rotating outdoor sign-offs bring Sierra's requested brand voice to ordinary replies while keeping factual content and exact catalog descriptions intact.

**Scope tradeoff.** A terminal demo and static files fit the 2–3 hour assignment. They do not solve peak-season production capacity. Load testing and deployment are deferred; the README lists production upgrades.

## Decisions implemented in the MVP

### Hand-written tool-calling loop

The model interprets customer wording and selects between the order-lookup and product-search tools. Promotion handling stays entirely in Python: promotion details are absent from the model instructions and tool list. Python validates tool calls and owns order matching, product lookup, promotion timing, and code creation. No agent framework is used, per the assignment.

### Facts and conversation context

System instructions and the latest non-promotion conversation items are sent to the Responses API. Promotion turns are handled in Python and omitted from model history; mixed turns send only independent non-promotion clauses. Recent model-visible turns and their tool calls/results are kept in memory for the process, bounded to the latest eight user turns. There is no database or cross-session memory. Customer messages can contain an email/order number, so those details are sent to OpenAI as part of the request; this demo uses fictional appendix data only.

Application code, not the model, matches order credentials and computes promotion eligibility. Promotion configuration, eligibility results, and generated codes are never sent to the model. The history trimmer preserves complete model-visible user-turn groups and associated tool items. The app also keeps a minimal matched-order summary locally for an order-content follow-up, without requiring the customer to resend credentials in that same follow-up.

### Order privacy, matching, and item details

The lookup requires both email and order number and returns no record unless both match. It normalizes email case, trims whitespace, and normalizes order-number case. Customer names are not returned. Every matched-order reply includes status, a tracking link when present, and product names resolved from recorded SKUs. Unknown SKUs are labeled without guessing. For an `error` status, the reply says the record supplies no cause or resolution. The current process retains a minimal verified order summary for follow-up questions; it is cleared on an unmatched lookup or when the customer asks about a different order. This is conversation convenience, not authentication for a real commerce system.

Order SKU values are resolved against exact catalog SKUs. A match returns the catalog title. An unmatched SKU is represented as `Unknown product (SKU: …)` using the value from the matched order row; malformed or missing identifiers are labeled `Unknown product (SKU unavailable)`. The agent does not infer a title from a similar SKU or add missing products to the catalog. For example, W009 can be reported as Nat's Infinity Pro Hairbrush plus `Unknown product (SKU: SOGK009)`.

Statuses with no tracking number do not get a fabricated link. The `error` state has no cause in the data, so the response must not invent one.

### Product answers

Search is a small deterministic token-overlap search over product name, description, SKU, and tags, with typo recovery limited to product-name tokens so incidental description words do not create typo matches. The catalog is tokenized once when the agent starts; each customer turn only tokenizes the query and ranks the cached entries. A SKU-to-title map also avoids rebuilding the catalog lookup for each order. The model may summarize returned records but must not invent features or assume a keyword hit means the item suits the customer's need. Inventory is omitted from search results because a static quantity is not dependable live availability. This is simple and inspectable but weak on synonyms, ranking quality, and ambiguous needs.

### Promotion policy

Python intercepts discount or approved offer-name mentions before model routing. The model prompt and tool list contain no promotion name, discount percentage, time window, or issuing capability. Outside the configured window, Python returns a fixed no-discount response without exposing offer terms; during the window, Python answers inquiries and issues codes for explicit requests. Promotion turns are omitted from model history, and mixed turns send only independent non-promotion clauses to the model. The clock is aware and interpreted in `America/Los_Angeles`; the window is 08:00 inclusive to 10:00 exclusive. Missing, naive, or failing clocks fail closed. A generated code is random and held in memory on the `SierraAgent` instance. Repeated requests through that instance reuse it; a new CLI run starts fresh. This is per-session behavior, not per-customer behavior, and does not guarantee global uniqueness or checkout redemption.

#### Promotion identity choices

“Per user” requires a defined identity and reuse rule:

| Policy | Identity and persistence | Advantages | Limitations |
|---|---|---|---|
| Per CLI session (current) | One in-memory code per running `SierraAgent` | Minimal and useful for a local demo | Restarts lose the code; separate sessions do not share state; no customer identity |
| Per email (prototype) | Normalized email maps to a persisted issuance | Easy to demonstrate reuse across runs | An unverified email is not proof that the requester owns it; shared storage and retention rules are needed |
| Per account (recommended for a real customer experience) | Stable authenticated customer ID maps to campaign issuance | Durable reuse without treating typed email as authentication | Requires account identity and persistent storage/service |
| Per request | Generate a new code for every request | Simple issuance semantics | Enables repeated code creation and usually conflicts with one-per-customer intent |

For durable per-customer issuance, make issuance idempotent for `(campaign, customer_id)`, enforce unique codes in storage, and handle simultaneous requests atomically. SQLite can support a single-user prototype; deployed traffic needs shared storage or a promotion service. Store issuance time and optional expiry/redemption state. If codes must work at checkout, integrate with the storefront; random generation alone does not reserve or validate a discount.
### Errors and limits

The request has a finite timeout, at most one retry for network/429/server errors, and a maximum of four tool rounds. The agent gives a generic recovery message rather than exposing API response details or credentials. Malformed local data is reported during startup. More complete observability, rate limits, circuit breaking, and graceful service-level fallback are deferred.

### Testing and success criteria

The standard-library `unittest` suite checks deterministic rules and a mocked tool loop without using the network. A fixed-clock seam makes promotion boundary, timezone conversion, and invalid-clock tests repeatable. Hard requirements are zero privacy/promotion-rule violations and passing deterministic checks; the model scorecard targets at least 95% tool selection and 90% conversation quality on held-out examples. Rule violations remain zero-tolerance even when the aggregate score is high. The scenarios and one-change-at-a-time improvement cycle live in `EVALUATION.md`.

### Hostility, gaming, and stalled conversations

Customer hostility alone is not a reason to refuse service: the prompt directs the model to stay calm, and an insulting message with a valid order request still takes the deterministic order path. The order lookup requires both supplied fields to match, so prompt injection cannot make an unmatched result reveal the matching order. For repetitive, deterministic out-of-scope requests, the agent gives its normal concise scope answer twice and then a firmer routing boundary. This is a soft boundary: it does not end or lock the CLI session, and a subsequent catalog or order question resets the counter. Three turns is an initial usability choice, not a proven optimum; tune it against real transcripts and ensure production escalation exists for stuck/high-impact cases. The prototype must not represent its boundary as a transfer to a human because no such channel is implemented.

Clearly unrelated requests are stopped before model routing with one deterministic response that names the supported order and catalog scope. The scope gate uses intent phrases and local catalog-term overlap to distinguish likely in-scope messages; promotion requests are handled separately in Python before model routing. Unmistakable unrelated tasks such as translation, trivia, or weather requests go directly to the fallback. A conservative lexical gate can miss unusual product phrasing, so include paraphrases in evaluation and update the cues when false rejections appear. Order and product requests continue through their existing model/tool workflow; promotion requests stay in the Python-only path.

## Source-data observations

The appendices PDF contains ten order rows and ten catalog rows. Transcribed catalog/order IDs do not fully agree:

- Orders use `SOBN008`; the catalog has `SOSV008` for the protein bars.
- Order `#W004` includes `SOCH010`; the catalog contains `SOSV010` for a lampshade.
- Orders use `SOGK009`; the catalog has `SOSV009` for red shoes.

These may be intentional mismatches or typos. The MVP preserves the appendix values instead of silently mapping them. An order SKU without an exact catalog match is shown as an unknown product with its recorded SKU after the order is matched; product search uses catalog rows independently. The agent does not infer or insert a catalog entry.

## Edge cases to handle now

These affect correctness, privacy, or basic usability and should be covered in manual acceptance walkthroughs before the onsite:

- An order request lacks email, lacks order number, or supplies them across turns: ask for the missing value, then require both.
- Email or order number is wrong, casing differs, or no record matches: do not reveal partial-match information or another customer's record.
- A matched order has a null tracking number: give the recorded status and items, clearly say tracking is unavailable in the sample record, and do not construct a null URL.
- A matched order includes both catalogued and unmatched SKUs: list exact catalog titles and label remaining lines as unknown using their recorded SKU; do not guess a title.
- An order status is `error`: report the recorded status and items, say the source provides no cause or resolution, and do not claim it was fixed or escalate unless a real support path exists.
- A product search has no results or asks for a fact absent from the catalog: say the catalog cannot confirm it and ask a focused follow-up if useful.
- A customer asks about stock: don't present the static inventory snapshot as live availability.
- A customer asks about the promotion outside the window, at either boundary, or asks only when it runs: only issue when the customer explicitly requests it and the time rule passes.
- The model returns malformed/unknown tool arguments or asks to run multiple tools: validate arguments, reject unknown tools, and cap tool rounds.
- API timeout, transient status, invalid response JSON, unavailable key, or missing data files: provide a safe recoverable error; never print the API key.
- A customer message contains instructions to bypass checks: treat it as untrusted input and keep code-level checks authoritative.
- A customer types real personal information: remember it is sent to the model API in this MVP; use only the synthetic fixture data until privacy/security approval for real data.

## Scaling and production concerns (deferred)

Peak demand changes the architecture beyond this CLI: replace static JSON with dependable order/catalog services; authenticate the customer through the retailer's identity flow; use a shared promotion service with atomic uniqueness/idempotency; enforce rate and spend limits; add bounded backoff and service health monitoring; track latency, tool success, no-match rates, and safe escalation rates without logging sensitive order details; define a real handoff for order errors and product issues; and evaluate model/tool behavior against a representative set of customer requests.

The MVP does not claim to be safe for concurrent customers, provide live inventory, guarantee code redemption, or meet a production availability target.

## Open questions for Sierra

1. Is the promotion window 8:00–9:59 AM inclusive, with 10:00 AM excluded?
2. Should a valid promotion code be unique per conversation/session, per customer, or globally and redeemable once?
3. If per customer, what stable identity is available (authenticated account ID, verified email, or something else)?
4. Should a code be reusable for multiple checkouts, or single-use and connected to storefront redemption?
5. How should customers with an `error` order be directed when no support contact or escalation path is provided?
6. Should recommendations account for inventory, and if so, which inventory source is authoritative?
7. For product issues outside catalog Q&A, what policies and human handoff should the agent follow?

## Progress record

- **Current:** terminal MVP, static appendix fixtures, documentation, and offline unit tests are present. The promotion clock can be injected for deterministic checks. Order contents resolve catalogued SKUs and explicitly label unmatched SKUs.
- **Verified:** offline deterministic unit tests pass; the CLI has been manually exercised with synthetic data. These checks do not establish production identity, durable promotion issuance, or checkout redemption.
- **Next:** complete the manual evaluation scorecard; decide whether session-scoped promotion behavior is sufficient or a durable customer identity is required; implement persistence or storefront integration only after identity and reuse semantics are agreed.
