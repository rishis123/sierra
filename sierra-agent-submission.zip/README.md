# Sierra Outfitters Support Agent

A small terminal agent for Sierra Outfitters' assessment. It supports order status and tracking, catalog-grounded product recommendations, and the Early Risers 10% promotion. The project uses a hand-written tool-calling loop and Python's standard library; it does not use an agent framework.

## Status

The CLI MVP and offline tests are in place. The CLI has been exercised with synthetic customer data; the full manual evaluation scorecard has not been completed.

## Requirements

- Python 3.10 or newer
- An OpenAI API key authorized for `gpt-4.1-mini`
- Network access to `api.openai.com`

Install the project dependencies with `python -m pip install -r requirements.txt`. On Windows, also install the timezone data package with `python -m pip install tzdata` if `America/Los_Angeles` is unavailable.

## Setup and run

Put the key in the project-root `.env` file, then start the CLI:

```bash
python3 -m pip install -r requirements.txt
OPENAI_API_KEY=your-key
python3 sierra_agent.py
```

The agent loads `.env` on startup and uses `OPENAI_API_KEY` from it unless the shell already defines that variable. `.env` is ignored by Git. The workspace also enables VS Code's Python terminal env-file injection so integrated terminals can read the same file.

On PowerShell:

```powershell
python sierra_agent.py
```

Type a customer message at `You:`. Type `quit` or `exit` to close the program. Conversation context is kept in memory for the current run only. Nothing is written to a conversation log.

**Data handling:** customer messages, including an email or order number the customer types, are sent to the OpenAI API as conversation context. The sample data is fictional. Do not use real customer information for a production workflow without Sierra's privacy and security approval.

Never paste a real API key into source code, commit it, or include it in the submission ZIP. The key appeared in the assignment text pasted into this chat; ask Sierra for a rotated/reissued key before using it.

## What the agent does

- **Order status and contents:** requires both email and order number to match a static order record before disclosing order details. Every matched-order response includes status, a USPS tracking URL when present, and the recorded items. Each order SKU is mapped to its exact catalog title when possible. Unmatched entries are labeled `Unknown product (SKU: …)` from the matched order record; the agent does not guess a title or add it to the catalog. For an `error` record, it says the cause and resolution are not provided. A successfully matched order can support follow-up questions during the current CLI run.
- **Opening and tone:** starts with a concise explanation of order tracking, catalog searches, and product questions. Matched order replies and ordinary model replies get a brief, predictable rotating outdoor sign-off. Exact catalog descriptions stay unchanged; fixed policy, promotion, and API recovery responses keep their defined wording.
- **Product recommendations:** indexes catalog words once at startup, then searches product names, descriptions, and tags with bounded typo correction against product-name words. The model can interpret clear synonyms and normalize them into catalog terms; ambiguous wording should trigger a clarifying question. Recommendations are grounded in returned catalog rows. The inventory field is intentionally not presented as live availability.
- **Early Risers:** Python handles every discount mention before model routing. A direct request for a discount or the approved name “Early Risers” / “Early Riser” is honored only from 8:00 AM inclusive until 10:00 AM exclusive in `America/Los_Angeles`. Outside the window, replies say “Sorry, no discounts are available at the moment” without exposing the offer terms. The promotion details are absent from the model prompt and tool list, and promotion turns are not stored in model conversation history. Mixed turns send only independent non-promotion clauses to the model. An invalid or unavailable clock fails closed. The generated code is held in memory for this CLI session.

The model interprets customer wording, resolves clear typos or synonyms to catalog terms, and selects an order or product tool. Python performs data lookup, bounded typo matching, promotion routing, time checks, and code generation. If wording is ambiguous, information is missing, or no source record matches, the agent should ask a brief clarifying question or say so instead of guessing.

## Example prompts

Use the sample customer data in `data/`:

- `Where is my order?` (the agent should ask for email and order number)
- `john.doe@example.com, order #W001`
- `I'm looking for a backpack for hiking. What do you recommend?`
- `Can I get the Early Risers promotion?`

The promotion example only returns a code during the configured time window. The clock can be injected in code for automated checks; the interactive CLI does not yet expose a demo-time override, so demonstrate the full flow during the valid window.

## Tests and success criteria

Run the offline suite from this directory:

```bash
python3 -m unittest discover -s tests -v
```

It uses Python's standard `unittest` library and makes no API calls. Success means all deterministic privacy and business-rule checks pass, with no unsupported facts; for live model conversations, the target is at least 90% across task selection, factuality, reasonable clarification, and tone, while rule violations remain zero-tolerance. See [EVALUATION.md](EVALUATION.md) for the manual scorecard and iteration cycle.

## Data notes

`data/CustomerOrders.json` and `data/ProductCatalog.json` were transcribed from the supplied appendices PDF. The order file refers to product IDs that do not all appear in the catalog: `SOBN008`, `SOCH010`, and `SOGK009` have no exact catalog SKU match; `SOSV008` and `SOSV010` appear in the catalog instead of some similar-looking order IDs. These source inconsistencies are preserved rather than silently corrected. Product recommendations do not infer products from order IDs.

The datasets are static assessment fixtures, not production data. Their inventory numbers and tracking information can be stale. The project contains no real customer credentials or service connection.

## Important MVP limits

- Order matching is exact after trimming whitespace and normalizing email case and order-number case. It is not identity verification suitable for a real account system.
- Product search uses cached word sets, word overlap, and bounded edit-distance typo correction against product names; it is not embedding-based semantic search. Synonym handling depends on the model translating clear terms into catalog vocabulary and may miss niche or ambiguous equivalents.
- A `fulfilled` record with no tracking number is reported without inventing a link. For an `error` record, the agent reports that the source provides no cause or resolution; it cannot resolve the issue or contact support.
- Promotion codes are generated in memory and are not reserved in a shared system. One running CLI session reuses its code if requested again. There is no customer identity attached to the code, no reuse across restarts, and no coordination across processes; this is session-scoped demo behavior, not per-user issuance.
- Conversation history is bounded to the latest eight user turns, including their associated tool-call/result items; it is not summarized or retained between runs.
- The model call retries once for network errors, HTTP 429, and server errors. It has a 25-second request timeout and a four-round tool-call cap.

## Next steps

In priority order:

1. Complete the manual model scorecard in [EVALUATION.md](EVALUATION.md), using synthetic data and recording any failures as regression cases.
2. Decide whether promotion codes are per CLI session, per customer, or globally unique and single-use. The current implementation is per running session.
3. If codes should be per customer, choose a stable identity. Prefer an authenticated account ID; email can be a prototype key but is not proof of identity unless verified.
4. For durable per-customer issuance, persist the campaign, customer key, code, issue/expiry state, and redemption state. Enforce idempotency and code uniqueness atomically; SQLite is suitable for a local prototype, while deployed traffic needs a shared service/database.
5. If codes must work at checkout, connect issuance and redemption limits to the storefront. The current random string generator does not reserve or validate codes there.
6. Review the eight-turn context limit with longer dialogues and decide when to ask again versus retain customer-provided order details.
7. Before service deployment, add privacy-safe operational metrics, rate limits, stronger retry/backoff behavior, and a real support handoff for unresolved problems.

See [DECISIONS.md](DECISIONS.md) for the design rationale, known edge cases, and deferred work.
